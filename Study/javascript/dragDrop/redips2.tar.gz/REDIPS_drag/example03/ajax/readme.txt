Darko Bunic
http://www.redips.net/javascript/drag-and-drop-example-3/
Aug, 2011.

Here is AJAX variant of demo. To enable AJAX method, open index.php in parent directory and replace the following line:
	<script type="text/javascript" src="script.js"></script>
with:
	<script type="text/javascript" src="ajax/script.js"></script>

Printing subjects or spreading school objects across week are not supported in AJAX demo.
