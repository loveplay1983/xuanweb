<?php 
// accept submited values
$fname = $_POST['fname'];
$lname = $_POST['lname'];
$email = $_POST['email'];

// save to database
// ..
// ..

// if everything went OK, then return string 'OK'
print 'OK';
?>